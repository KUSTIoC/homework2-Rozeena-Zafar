
package Mypackage2;
public class EmployeeTest {
    public static void main(String[] args) {
        Employee obj1=new Employee("abdul","wasay",25000);
        Employee obj2=new Employee("abdul","shavaiz",20000);
        System.out.println( obj1.getFirst_name() +"  "+obj1.getLast_name()+"  " + " yearly salary of obj1= "+obj1.yearlySalary(25000.0)+"  "+"yearly salary of obj1 after including 10% of salary= "+obj1.finalyearlysalary(25000.0));
        System.out.println( obj2.getFirst_name()+"   "+obj2.getLast_name()+"  " + "yearly salary of obj2= "+obj2.yearlySalary(20000.0)+"  "+"yearly salary of obj1 after including 10% of salary= "+obj2.finalyearlysalary(25000.0));
       
    }
    
}
