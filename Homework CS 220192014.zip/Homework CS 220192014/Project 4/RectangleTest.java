
package mypackge4;
public class RectangleTest {
    public static void main(String[] args) {
        Rectangle obj=new Rectangle();
       obj.setLength(2.3);
       obj.setWidth(4.8);
       System.out.println("length=  " + obj.getLength()+ "  "+ "width= " + obj.getWidth());
       System.out.println("perimeter of rectangle= "+obj.perimeter());
       System.out.println("Area of rectangle= " +obj.area());
        // TODO code application logic here
    }
    
}
