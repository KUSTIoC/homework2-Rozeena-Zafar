
package mypackage3;
public class DateTest {
    public static void main(String[] args) {
       Date obj=new Date(3,24,2020);
       obj.setDay(15);
       obj.setMonth(3);
       obj.setYear(2019);
       
       System.out.printf("Date =   "+obj.displayDate());
        // TODO code application logic here
    }
    
}
