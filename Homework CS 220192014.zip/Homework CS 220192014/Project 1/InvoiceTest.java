
package mypackge1;
public class InvoiceTest {
    public static void main(String[] args) {
        
        Invoice obj1= new Invoice("C101","os",5,200.0);
        obj1.setPartNum("C100");
        obj1.setPartDesc("Database");
        obj1.setPricePerItem(30.0);
        obj1.setQuantity(3);
        
        System.out.println("        invoice detail               ");
        System.out.println("Part number= "+obj1.getPartNum());
        System.out.println("Part description= "+obj1.getPartDesc());
        System.out.println("Price per item= "+obj1.getPricePerItem());
        System.out.println("Invoice Amount= "+obj1.getInvoiceAmount());
                
        // TODO code application logic here
    }
    
}
