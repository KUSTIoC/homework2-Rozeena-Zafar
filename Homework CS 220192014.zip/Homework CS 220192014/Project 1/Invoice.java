
package mypackge1;
public class Invoice {
    private String part_Num;
    private String part_Desc;
    private int quantity;
    private double price_Per_Item;
    private double Invoice;

    public Invoice(String part_Num, String part_Desc, int quantity, double price_Per_Item) {
        this.part_Num = part_Num;
        this.part_Desc = part_Desc;
        this.quantity = quantity;
        this.price_Per_Item = price_Per_Item;
    }

    public void setPartNum(String part_Num) {
        this.part_Num = part_Num;
    }

    public void setPartDesc(String part_Desc) {
        this.part_Desc = part_Desc;
    }

    public void setQuantity(int quantity) {
        if(quantity<0)
        {
            this.quantity=0;
        }
        this.quantity = quantity;
    }

    public void setPricePerItem(double price_Per_Item) {
        if(price_Per_Item<0)
        {
            this.price_Per_Item=0;
        }
        this.price_Per_Item = price_Per_Item;
    }

    public String getPartNum() {
        return part_Num;
    }

    public String getPartDesc() {
        return part_Desc;
    }

    public int getItemPurchased() {
        return quantity;
    }

    public double getPricePerItem() {
        return price_Per_Item;
    }
    public double getInvoiceAmount(){
        Invoice=quantity*price_Per_Item;
        return Invoice;
    }
    
}
